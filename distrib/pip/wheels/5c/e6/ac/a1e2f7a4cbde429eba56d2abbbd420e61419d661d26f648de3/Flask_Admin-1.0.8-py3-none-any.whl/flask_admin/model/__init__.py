from .base import BaseModelView
from .form import InlineFormAdmin
from flask.ext.admin.actions import action
